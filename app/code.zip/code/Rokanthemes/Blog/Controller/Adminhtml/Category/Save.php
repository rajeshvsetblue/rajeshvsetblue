<?php
/**
 * Copyright © 2015 RokanThemes.com. All rights reserved.

 * @author RokanThemes Team <contact@rokanthemes.com>
 */

namespace Rokanthemes\Blog\Controller\Adminhtml\Category;

/**
 * Blog category save controller
 */
class Save extends \Rokanthemes\Blog\Controller\Adminhtml\Category
{

}
