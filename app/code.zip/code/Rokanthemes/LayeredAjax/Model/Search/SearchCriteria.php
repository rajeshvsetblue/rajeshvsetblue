<?php

namespace Rokanthemes\LayeredAjax\Model\Search;

use Magento\Framework\Api\Search\SearchCriteria as SourceSearchCriteria;

class SearchCriteria extends SourceSearchCriteria
{
}
