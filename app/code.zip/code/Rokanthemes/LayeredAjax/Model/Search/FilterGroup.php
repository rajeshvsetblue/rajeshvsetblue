<?php

namespace Rokanthemes\LayeredAjax\Model\Search;

use Magento\Framework\Api\Search\FilterGroup as SourceFilterGroup;

class FilterGroup extends SourceFilterGroup
{
}
