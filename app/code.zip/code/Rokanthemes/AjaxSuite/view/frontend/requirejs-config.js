
var config = {
    map: {
        '*': {
            'rokanthemes/ajaxsuite': 'Rokanthemes_AjaxSuite/js/ajaxsuite',
            'Rokanthemes_AjaxSuite/js/model/ajaxsuite-popup':'Rokanthemes_AjaxSuite/js/model/ajaxsuite-popup',
            'Magento_Customer/template/authentication-popup':'Rokanthemes_AjaxSuite/template/authentication-popup',
            'Magento_Customer/js/model/authentication-popup':'Rokanthemes_AjaxSuite/js/model/authentication-popup'
        }
    }
};
