var config = {

	map: {
		'*': {
			'magicproduct'	: "Magiccart_Magicproduct/js/magicproduct",
		},
	},

	shim: {
		'magicproduct': {
			deps: ['jquery', 'magiccart/slick']
		},

	}
};
