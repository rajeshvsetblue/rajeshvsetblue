<?php
/**
 * Magiccart 
 * @category    Magiccart 
 * @copyright   Copyright (c) 2014 Magiccart (http://www.alothemes.com/) 
 * @license     http://www.alothemes.com/license-agreement.html
 * @Author: DOng NGuyen<nguyen@dvn.com>
 * @@Create Date: 2015-12-14 20:26:27
 * @@Modify Date: 2020-07-17 16:44:21
 * @@Function:
 */

namespace Magiccart\Magicproduct\Helper;

// use \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig;

class Alothemes extends Data
{
    public function getTimer($_product)
    {

    }

    public function getLabels($_product)
    {

    }
}
