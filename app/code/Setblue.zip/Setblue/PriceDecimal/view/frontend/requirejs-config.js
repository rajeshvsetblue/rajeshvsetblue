var config = {
    map: {
        '*': {
            'Magento_Catalog/js/price-utils' : 'Setblue_PriceDecimal/js/price-utils'
        }
    }
};