<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FME\StorePickup\Model;

/**
 * Catalog image uploader
 */
class ImageUploader extends \Magento\Catalog\Model\ImageUploader
{
    
}
